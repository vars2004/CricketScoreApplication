package com.example.cricketscoreapllication

data class Score(
    var runs: Int,
    var wickets: Int,
    var overs: Int,
    var innings: String,
)
