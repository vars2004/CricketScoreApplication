package com.example.cricketscoreapllication

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray

class MatchScoreActivity : AppCompatActivity() {

    lateinit var matchTitleTV: TextView
    lateinit var matchNameTV: TextView
    lateinit var team1TV: TextView
    lateinit var team2TV: TextView
    lateinit var team1ScoreTV: TextView
    lateinit var team2ScoreTV: TextView
    lateinit var matchStatusTV: TextView
    lateinit var matchDateTV: TextView
    lateinit var matchTypeTV: TextView
    lateinit var matchVenueTV: TextView
    lateinit var matchTossTV: TextView
    lateinit var loadingPB: ProgressBar
    var apiURL: String = "https://api.cricapi.com/v1/match_info?api_key=49f314d8-b84d-47b5-a26e-5d54da83f0a0&id="
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_match_score)
        matchTitleTV = findViewById(R.id.idTVMatchTitle)
        matchNameTV = findViewById(R.id.idTVMatchName)
        team1TV = findViewById(R.id.idTVTeam1)
        team2TV = findViewById(R.id.idTVTeam2)
        team1ScoreTV = findViewById(R.id.idTvScore1)
        team2ScoreTV = findViewById(R.id.idTvScore2)
        matchStatusTV = findViewById(R.id.idTVMatchStatus)
        matchDateTV = findViewById(R.id.idTVMatchDate)
        matchTypeTV = findViewById(R.id.idTVMatchType)
        matchVenueTV = findViewById(R.id.idTVMatchVenue)
        matchTossTV = findViewById(R.id.idTVMatchToss)
        loadingPB = findViewById(R.id.idPBLoading)

        val matchID = intent.getStringExtra("matchID")

        val queue: RequestQueue = Volley.newRequestQueue(applicationContext)
        val request = JsonObjectRequest(Request.Method.GET, apiURL, null, { response ->
            try {
                val dataObj = response.getJSONObject("data")
                loadingPB.visibility = View.GONE
                val teamsList = ArrayList<String>()
                val scoreCardList = ArrayList<Score>()
                val matchScoreRVList = ArrayList<MatchesRVModal>()

                val matchName: String = dataObj.getString("name")
                val matchType: String = dataObj.getString("matchType")
                val matchStatus: String = dataObj.getString("status")
                val matchVenue: String = dataObj.getString("venue")
                val matchDate: String = dataObj.getString("date")

                val teamArray = dataObj.getJSONArray("teams")
                for (j in 0 until teamArray.length()) {
                    teamsList.add(teamArray.getString(j))
                }
                val scoreArray: JSONArray = dataObj.getJSONArray("score")
                for (k in 0 until scoreArray.length()) {
                    val scoreObj = scoreArray.getJSONObject(k)
                    val runs = scoreObj.getInt("r")
                    val overs = scoreObj.getInt("o")
                    val wickets = scoreObj.getInt("w")
                    val innings = scoreObj.getString("inning")
                    scoreCardList.add(Score(runs, wickets, overs, innings))

                }
                var tossWinner = dataObj.getString("tossWinner")
                var tossChoice = dataObj.getString("tossChoice")


                matchTitleTV.text = matchName
                matchNameTV.text = matchName
                matchTypeTV.text = matchType
                matchStatusTV.text = matchStatus
                matchVenueTV.text = matchVenue
                matchDateTV.text = matchDate
                team1TV.text = teamsList.get(0)
                team2TV.text = teamsList.get(1)
                matchTossTV.text = tossWinner + " won the toss and chose " + tossChoice

                team1ScoreTV.text =
                    scoreCardList.get(0).runs.toString() + "/" + scoreCardList.get(0).wickets.toString() + "(" + scoreCardList.get(
                        0
                    ).overs.toString() + ")"
                team2ScoreTV.text =
                    scoreCardList.get(1).runs.toString() + "/" + scoreCardList.get(1).wickets.toString() + "(" + scoreCardList.get(
                        1
                    ).overs.toString() + ")"


            } catch (e: Exception) {
                e.printStackTrace()

            }
        }, { error ->
            Toast.makeText(
                applicationContext,
                "Fail to get score details : " + error,
                Toast.LENGTH_SHORT
            ).show()
        })
        queue.add(request)

    }
}