package com.example.cricketscoreapllication

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Request.Method
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.cricketscoreapllication.ui.theme.CricketScoreApllicationTheme
import org.json.JSONArray

class MainActivity : ComponentActivity() {
    private val matchScoreRVList: MutableList<MatchesRVModal> = mutableListOf()
    var apiURL: String =
        "https://api.cricapi.com/v1/currentMatches?apikey=49f314d8-b84d-47b5-a26e-5d54da83f0a0&offset=0"
    lateinit var matchRV: RecyclerView
    lateinit var loadingPB: ProgressBar


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        matchRV = findViewById(R.id.idRVMatches)
        loadingPB = findViewById(R.id.idPBLoading)

        val queue: RequestQueue = Volley.newRequestQueue(applicationContext)

        val request = JsonObjectRequest(Request.Method.GET, apiURL, null, { response ->

            try {
                    val dataArray = response.getJSONArray("data")
                loadingPB.visibility = View.GONE
                matchRV.visibility = View.VISIBLE

                val matchesList = ArrayList<MatchesRVModal>()

                for(i in 0 until dataArray.length()) {
                    val dataobj = dataArray.getJSONObject(i)
                    val matchName: String = dataobj.getString("name")
                    val matchType: String = dataobj.getString("matchType")
                    val matchstatus: String = dataobj.getString("status")
                    val matchvenue: String = dataobj.getString("venue")
                    val matchdate: String = dataobj.getString("date")
                    val matchID: String = dataobj.getString("id")

                    val teamList = ArrayList<String>()
                    val scoreCardList = ArrayList<Score>()

                    var teamsArray: JSONArray = dataobj.getJSONArray("teams")
                    for (j in 0 until teamsArray.length()) {
                        teamList.add(teamsArray.getString(j))
                    }
                    var scoreCardArray: JSONArray = dataobj.getJSONArray("score")
                    for (k in 0 until scoreCardArray.length()) {
                        var scoreObj = scoreCardArray.getJSONObject(k)
                        var runs = scoreObj.getInt("r")
                        var overs = scoreObj.getInt("o")
                        var wickets = scoreObj.getInt("w")
                        var innings = scoreObj.getString("inning")
                        scoreCardList.add(Score(runs, wickets, overs, innings))

                    }
                    matchScoreRVList.add(MatchesRVModal(matchName, matchType, matchstatus, matchvenue, matchdate, matchID, teamList, scoreCardList))

                }
                val matchRVAdapter = MatchesRVAdapter(matchScoreRVList, this)
                matchRV.adapter = matchRVAdapter


            } catch (e: Exception) {
                e.printStackTrace()

            }
        }, {

                error ->
            Toast.makeText(applicationContext, "Fail to get data" + error, Toast.LENGTH_SHORT)
                .show()


        })
        queue.add(request)

    }
}