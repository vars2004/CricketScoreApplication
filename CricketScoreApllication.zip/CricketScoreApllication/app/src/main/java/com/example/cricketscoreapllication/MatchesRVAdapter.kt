package com.example.cricketscoreapllication

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MatchesRVAdapter(private val matchList: List<MatchesRVModal>, private val ctx: Context): RecyclerView.Adapter<MatchesRVAdapter.ViewHolder>() {


    class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val matchTitleTv: TextView = itemView.findViewById(R.id.idTVMatchTitle)
        val team1Tv: TextView = itemView.findViewById(R.id.idTVTeam1)
        val team2Tv: TextView = itemView.findViewById(R.id.idTVTeam2)
        val score1Tv: TextView = itemView.findViewById(R.id.idTvScore1)
        val score2Tv: TextView = itemView.findViewById(R.id.idTvScore2)
        val StatusTv: TextView = itemView.findViewById(R.id.idTVMatchStatus)


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.match_rv_item, parent, false)
        return ViewHolder(view)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        holder.matchTitleTv.text = matchList.get(position).matchName
         holder.StatusTv.text = matchList.get(position).status

        val teamList: List<String> = matchList.get(position).teams
        holder.team1Tv.text = teamList.get(0)
        holder.team2Tv.text = teamList.get(1)

        val scoreList: List<Score> = matchList.get(position).scores
        holder.score1Tv.text = scoreList.get(0).runs.toString() + "/" + scoreList.get(0).wickets + "(" + scoreList.get(
            0
        ).overs + ")"

        if(matchList.get(position).scores.size==2){
            holder.score2Tv.text = scoreList.get(1).runs.toString() +"/" + scoreList.get(1).wickets + "(" + scoreList.get(
                1
            ).overs + ")"

        }

        holder.itemView.setOnClickListener {
            val intent = Intent(ctx, MatchScoreActivity::class.java)
            intent.putExtra("matchID", matchList.get(position).matchID)
            ctx.startActivity(intent)

        }
    }
        override fun getItemCount(): Int {
        return matchList.size


    }
}